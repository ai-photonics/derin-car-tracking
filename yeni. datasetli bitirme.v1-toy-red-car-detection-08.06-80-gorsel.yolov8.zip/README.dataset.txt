# yeni. datasetli bitirme > toy red car detection 08.06 80 görsel
https://universe.roboflow.com/dofbot-arm/yeni-datasetli-bitirme

Provided by a Roboflow user
License: CC BY 4.0

